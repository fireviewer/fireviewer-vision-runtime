"""Compatibility alias; no second implementation is maintained here."""
from importlib import import_module as _import_module
import sys as _sys
_sys.modules[__name__] = _import_module("fireviewer_contracts.geometry_contract")
